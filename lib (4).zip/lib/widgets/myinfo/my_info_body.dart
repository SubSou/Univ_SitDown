import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:sitdown/api/user_api.dart';
import 'package:sitdown/constants/app_colors.dart';
import 'package:sitdown/providers/auth_provider.dart';
import 'package:sitdown/widgets/common/profilecircle.dart';
import 'package:sitdown/widgets/myinfo/my_info_item.dart';

class MyInfoBody extends StatefulWidget {
  const MyInfoBody({super.key});

  @override
  State<MyInfoBody> createState() => _MyInfoBodyState();
}

class _MyInfoBodyState extends State<MyInfoBody> {
  late TextEditingController nameController;
  late TextEditingController emailController;
  late TextEditingController phoneController;
  late TextEditingController affiliationController;

  final ImagePicker picker = ImagePicker();

  XFile? selectedImage;
  Uint8List? selectedImageBytes;

  bool isLoading = false;

  @override
  void initState() {
    super.initState();

    nameController = TextEditingController();
    emailController = TextEditingController();
    phoneController = TextEditingController();
    affiliationController = TextEditingController();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    final myInfo = context.watch<AuthProvider>().myInfo;

    nameController.text = myInfo?['name']?.toString() ?? '';
    emailController.text = myInfo?['email']?.toString() ?? '';
    phoneController.text = myInfo?['phone']?.toString() ?? '';
    affiliationController.text =
        myInfo?['affiliation']?.toString() ?? 'UNDERGRADUATE';

    print(myInfo?['affiliation']);
  }

  String convertAffiliation(String value) {
    switch (value.trim()) {
      case '학생':
      case '학부생':
        return 'UNDERGRADUATE';
      case '대학원생':
        return 'GRADUATE';
      case '교직원':
        return 'FACULTY';
      case '조교':
        return 'ASSISTANT';
      case '외부인':
        return 'EXTERNAL';
      default:
        return value.trim().isEmpty ? 'UNDERGRADUATE' : value.trim();
    }
  }

  Future<void> pickProfileImage() async {
    try {
      final XFile? image = await picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80,
      );

      if (image == null) return;

      final Uint8List bytes = await image.readAsBytes();

      setState(() {
        selectedImage = image;
        selectedImageBytes = bytes;
      });
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("이미지를 선택할 수 없습니다.")));
    }
  }

  Future<void> updateMyProfile() async {
    final accessToken = context.read<AuthProvider>().accessToken ?? '';

    if (accessToken.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("로그인이 필요합니다.")));
      return;
    }

    try {
      setState(() {
        isLoading = true;
      });

      final updatedUser = await UserApi.updateMyInfo(
        accessToken: accessToken,
        name: nameController.text.trim(),
        phone: phoneController.text.trim(),
        affiliation: convertAffiliation(affiliationController.text),
      );

      context.read<AuthProvider>().setMyInfo(updatedUser);

      if (selectedImage != null && selectedImageBytes != null) {
        final path = selectedImage!.path;
        //final pureUrl = path.replaceFirst('blob:', '');
        //print(pureUrl);
        final uploadedUser = await UserApi.uploadProfileImage(
          accessToken: accessToken,
          imageFile: path,
        );

        context.read<AuthProvider>().setMyInfo(uploadedUser);
      }

      if (!mounted) return;

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("회원정보가 수정되었습니다.")));
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("프로필 수정 중 에러가 발생 했습니다. 잠시 후 다시 실행해 주세요.")),
      );
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Widget buildProfileImage() {
    if (selectedImageBytes != null) {
      return ClipOval(
        child: Image.memory(
          selectedImageBytes!,
          width: 54,
          height: 54,
          fit: BoxFit.cover,
        ),
      );
    }

    return const ProFileCircle();
  }

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    phoneController.dispose();
    affiliationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: Column(
        children: [
          buildProfileImage(),

          const SizedBox(height: 12),

          Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(8),
              onTap: isLoading ? null : pickProfileImage,
              child: Ink(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFFEAF2FF),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  "프로필 사진 변경",
                  style: TextStyle(
                    color: Color(0xFF3F7FEA),
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
          ),

          Container(
            margin: const EdgeInsets.only(top: 28),
            padding: const EdgeInsets.symmetric(horizontal: 28),
            child: Column(
              children: [
                MyInfoItem(mainTitle: "이름", controller: nameController),
                MyInfoItem(mainTitle: "이메일", controller: emailController),
                MyInfoItem(mainTitle: "전화번호", controller: phoneController),
                MyInfoItem(mainTitle: "소속", controller: affiliationController),

                Container(
                  margin: const EdgeInsets.only(top: 24),
                  width: double.infinity,
                  height: 54,
                  child: Material(
                    color: isLoading ? greyColor : primaryColor,
                    borderRadius: BorderRadius.circular(12),
                    child: InkWell(
                      onTap: isLoading ? null : updateMyProfile,
                      borderRadius: BorderRadius.circular(12),
                      child: Center(
                        child: isLoading
                            ? const CircularProgressIndicator(
                                color: whiteColor,
                                strokeWidth: 2,
                              )
                            : const Text(
                                "수정하기",
                                style: TextStyle(
                                  color: whiteColor,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
