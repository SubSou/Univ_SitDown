import 'dart:typed_data';

import 'package:image_picker/image_picker.dart';
import 'package:sitdown/api/api_client.dart';

class UserApi {
  /// 내 정보 조회
  static Future<Map<String, dynamic>> getMyInfo({
    required String accessToken,
  }) async {
    final data = await ApiClient.get('/users/me', accessToken: accessToken);

    return Map<String, dynamic>.from(data);
  }

  /// 내 정보 수정
  static Future<Map<String, dynamic>> updateMyInfo({
    required String accessToken,
    String? name,
    String? phone,
    String? affiliation,
  }) async {
    final body = {
      if (name != null && name.trim().isNotEmpty) 'name': name.trim(),
      if (phone != null && phone.trim().isNotEmpty) 'phone': phone.trim(),
      if (affiliation != null && affiliation.trim().isNotEmpty)
        'affiliation': affiliation.trim(),
    };

    final data = await ApiClient.patch(
      '/users/me',
      accessToken: accessToken,
      body: body,
    );

    return Map<String, dynamic>.from(data);
  }

  /// 프로필 사진 업로드
  static Future<Map<String, dynamic>> uploadProfileImage({
    required String accessToken,
    required String imageFile,
  }) async {
    final data = await ApiClient.uploadFile(
      '/users/me/profile-image',
      accessToken: accessToken,
      filePath: imageFile,
    );

    return Map<String, dynamic>.from(data);
  }

  /// 내 즐겨찾기 공간 목록 조회 USER-04
  static Future<Map<String, dynamic>> getMyFavorites({
    required String accessToken,
    int page = 0,
    int size = 20,
  }) async {
    final data = await ApiClient.get(
      '/users/me/favorites',
      accessToken: accessToken,
      queryParameters: {'page': page, 'size': size},
    );

    return Map<String, dynamic>.from(data);
  }
}
